package com.cg.project.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Customer")
public class Customer {

	@Column(name="cust_name")
	private String name;
	
	@Id
	@Column(name="mobile_no")
	private String mobNo;
	
	@Column(name="age")
	private float age;
	
	@Column(name="ini_bal")
	private double initialBal;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public double getInitialBal() {
		return initialBal;
	}
	public void setInitialBal(double initialBal) {
		this.initialBal = initialBal;
	}
	public Customer(String name, String mobNo, float age, double initialBal) {
		super();
		this.name = name;
		this.mobNo = mobNo;
		this.age = age;
		this.initialBal = initialBal;
	}
	public Customer() {
		super();
	}
	
	
}
