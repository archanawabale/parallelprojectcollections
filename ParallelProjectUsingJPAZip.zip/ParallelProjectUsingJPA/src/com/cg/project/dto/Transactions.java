package com.cg.project.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Transactions")
public class Transactions {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int index;
	
	@Column(name="mobileno")
	private String mobNo;
	
	@Column(name="creditORdebit")
	private String credDeb;
	
	@Column(name="Balance")
	private double balance;
	
	@Column(name="amount")
	private double amount;
	
	@Column(name="transtime")
	private String date;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public String getCredDeb() {
		return credDeb;
	}

	public void setCredDeb(String credDeb) {
		this.credDeb = credDeb;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
