package com.cg.project.ui;

import java.util.Scanner;

import com.cg.project.dto.Customer;
import com.cg.project.exception.BankException;
import com.cg.project.service.BankServiceImpl;
import com.cg.project.service.IBankService;

public class ClientClass {
	static Scanner sc = null; 
	static String name,mobileNo;
	static float age;
	static double amount;
	
	static IBankService service=null;
	static Customer customer=null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		service = new BankServiceImpl();

		while(true){
			System.out.println("1.Create an Account \n2.Deposit the amount \n3.Withdraw the amount\n4.Fund transfer \n5.Check balance \n6.Exit");
			System.out.println("Enter your choice : ");
			sc=new Scanner(System.in);
			int ch = sc.nextInt();

			switch(ch){

			case 1:createAccount();
					break;
			case 2:depositAmount();
					break;
			case 3:withdrawAmount();
					break;
			case 4:fundTransfer();
					break;
			case 5:checkBalance();
					break;
			case 6:exit();
					break;
			default: exit();
			}
		}
	}
	private static void exit() {
		// TODO Auto-generated method stub
		System.out.println("Application terminated!!");
		System.exit(0);
	}
	private static void checkBalance() {
		// TODO Auto-generated method stub
			System.out.println("Enter the mobile number to check balance");
			mobileNo = sc.next();
			try {
				if(service.validateMobileNo(mobileNo)){
					if(service.validateAccount(mobileNo))
						System.out.println("Current Amount "+service.checkBalance(mobileNo));
					else
						System.out.println("Account doesnt exists!");
				}
			} catch (BankException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	private static void fundTransfer() {
		// TODO Auto-generated method stub
		
		String RxMobNo;
		System.out.println("Enter your mobile number : ");
		mobileNo = sc.next();
		try {
			if(service.validateMobileNo(mobileNo))
			{
				if(service.validateAccount(mobileNo))
				{	System.out.println("Enter the amount you want to transfer : ");
					amount = sc.nextDouble();
					if(service.validateAmount(amount))
					{
						System.out.println("Enter receivers mobile number : ");
						RxMobNo = sc.next();
						if(service.validateMobileNo(RxMobNo))
						{
							if(service.validateAccount(RxMobNo))
							{
								if(!mobileNo.equals(RxMobNo))
								{
									service.fundTransfer(mobileNo, RxMobNo, amount);
								}else {
									System.out.println("Sender and receiver mobile number cannot be same.");
								}
							}else{
								System.out.println("Account does not exist!");
							}
						}else{
							System.out.println("Account doesnt exists!");
						}
					}
				}else{
					System.out.println("Account doesnt exists!");
			}
		}
	}
		catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
		
	private static void withdrawAmount() {
		// TODO Auto-generated method stub
		System.out.println("Enter your mobile no. : ");
		mobileNo = sc.next();
		try {
			if(service.validateMobileNo(mobileNo))
			{
				System.out.println("Enter amount you want to deposit: ");
				amount = sc.nextDouble();
				if(service.validateAmount(amount))
				{
					if(!service.validateAccount(mobileNo))
						System.out.println("Account not found! Check mobile number");
					else
						customer = new Customer();
						service.withdraw(mobileNo, amount);		
				}
			}
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void depositAmount() {
		// TODO Auto-generated method stub
		System.out.println("Enter your mobile no. : ");
		mobileNo = sc.next();
		try {
			if(service.validateMobileNo(mobileNo))
			{
				System.out.println("Enter amount you want to deposit: ");
				amount = sc.nextDouble();
				if(service.validateAmount(amount))
				{
					if(!service.validateAccount(mobileNo))
						System.out.println("Account not found! Check mobile number");		
					else
						service.deposit(mobileNo, amount);
				}
			}
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	private static void createAccount() {
				// TODO Auto-generated method stub
		System.out.println("Enter customer name : ");
		name = sc.next();
		try {
			if(service.validateName(name))
			{
				System.out.println("Enter mobile no. : ");
				mobileNo = sc.next();
				if(service.validateMobileNo(mobileNo))
				{
					System.out.println("Enter age : ");
					age = sc.nextFloat();
					if(service.validateAge(age))
					{
						System.out.println("Enter initial amount : ");
						amount = sc.nextDouble();
						if(service.validateAmount(amount))
						{
							if(service.validateAccount(mobileNo))
							{
								System.out.println("Account already exists!");
							}
						}
					}
				}
				customer = new Customer();
				customer.setName(name);
				customer.setMobNo(mobileNo);
				customer.setAge(age);
				customer.setInitialBal(amount);
				service.createAccount(customer);		
				System.out.println("Customer added!");
			}
		} catch (BankException e)
		  {
			e.printStackTrace();
		  }
	}
}


