package com.cg.project.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.project.dao.BankDaoImpl;
import com.cg.project.dao.IBankDao;
import com.cg.project.dto.Customer;
import com.cg.project.exception.BankException;

public class BankServiceImpl implements IBankService {

	IBankDao dao  = new BankDaoImpl();
	
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		dao.createAccount(customer);
	}

	@Override
	public void deposit(String mobNo, double amount) {
		// TODO Auto-generated method stub
		dao.deposit(mobNo, amount);
		
	}

	@Override
	public void withdraw(String mobNo, double amount) {
		// TODO Auto-generated method stub
		dao.withdraw(mobNo, amount);
	}

	@Override
	public double checkBalance(String mobNo) {
		// TODO Auto-generated method stub
		return dao.checkBalance(mobNo);
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		dao.fundTransfer(sender, reciever, amount);
	}

	@Override
	public boolean validateAccount(String mobileNo) throws BankException {
		// TODO Auto-generated method stub
		return dao.validateAccount(mobileNo);
	}

	@Override
	public boolean validateName(String name) throws BankException {
		// TODO Auto-generated method stub
		if(name == null)
			throw new BankException("Null value found");
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{1,10}");
		Matcher m = p.matcher(name); 
		if(!m.matches())
			System.out.println("Name invalid! NAme should start with capital letter and should be of minimum 2 characters e.g Dinesh");
		return m.matches();
	}

	@Override
	public boolean validateAge(float age) throws BankException {
		// TODO Auto-generated method stub
		try{
			if(age == 0)
				throw new BankException("Age cannot be  null");
			else if(age >100)
				throw new BankException("Age cannot be  greater than 100");
			else if(age < 0)
				throw new BankException("Age cannot be a negative number");
			else if(age >17)
				return true;
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
	}
	

	@Override
	public boolean validateMobileNo(String mobNo) throws BankException {
		// TODO Auto-generated method stub
		try{
			if(mobNo == null)
				throw new BankException("Null value found");
			Pattern p = Pattern.compile("[6789][0-9]{9}");
			Matcher m = p.matcher(mobNo);
			if(!m.matches())
				System.out.println("Mobile Number Invalid! Please enter valid Indian mobile number of 10 digits e.g 9867988985");
			return m.matches();
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
}
	

	@Override
	public boolean validateAmount(double amount) throws BankException {
		// TODO Auto-generated method stub
		if(amount == 0)
			throw new BankException("Null value found");
		String am = String.valueOf(amount);
		if(!am.matches("\\d{3,9}\\.\\d{0,4}"))
			System.out.println("Invalid Amount! Minimum transaction amount is 100 ");
		return (am.matches("\\d{3,9}\\.\\d{0,4}"));
	}

}
