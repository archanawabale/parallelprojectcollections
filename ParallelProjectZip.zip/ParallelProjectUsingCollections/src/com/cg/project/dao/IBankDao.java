package com.cg.project.dao;

import com.cg.project.dto.Customer;
import com.cg.project.exception.BankException;

public interface IBankDao {

public void createAccount(Customer customer);
	
	public void deposit(String mobileNo, double amount);
	public void withdraw(String mobileNo, double amount);
	public double checkBalance(String mobileNo);
	public void fundTransfer(String sender, String reciever, double amount);
	public boolean validateAccount(String mobileNo) throws BankException;
	
}
