package com.cg.project.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.project.dto.Customer;
import com.cg.project.exception.BankException;

public class BankDaoImpl implements IBankDao {

Map<String,Customer> custMap;
	
	public BankDaoImpl(){
	custMap = new HashMap<>();
	custMap.put("9010210131", new Customer("9010210131", "Vaishali", 20, 5000));
	custMap.put("9823920123", new Customer("9823920123", "Megha", 45, 6000));
	custMap.put("9932012345", new Customer("9932012345", "Vikas", 63, 10000));
	}
	
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		custMap.put(customer.getMobNo(),customer);
	}

	@Override
	public void deposit(String mobNo, double amount) {
		// TODO Auto-generated method stub
		Customer customer = custMap.get(mobNo);
		if(customer != null){
			double updateAmount = customer.getInitialBal();
			updateAmount += amount;
			String name = customer.getName();
			String newMobileNo = customer.getMobNo();
			float age = customer.getAge();
			
			customer.setAge(age);
			customer.setInitialBal(updateAmount);
			customer.setName(name);
			customer.setMobNo(newMobileNo);
			
			custMap.put(newMobileNo, customer);
			System.out.println("Amount deposited! New balance: "+ customer.getInitialBal());
		}
	}

	@Override
	public void withdraw(String mobileNo, double withdrawAmount) {
		// TODO Auto-generated method stub
		Customer customer = custMap.get(mobileNo);
		if(customer != null){
			double amount = customer.getInitialBal();	
			
			String name = customer.getName();
			String newMobileNo = customer.getMobNo();
			float age = customer.getAge();
			
			if(amount - withdrawAmount > 500){
				amount -= withdrawAmount;
				customer.setAge(age);
				customer.setInitialBal(amount);
				customer.setName(name);
				customer.setMobNo(newMobileNo);
				
				custMap.put(newMobileNo, customer);
				System.out.println("Amount withdrawn! New balance: "+ customer.getInitialBal());
			}
			else{
				System.out.println("Cannot withdraw! Minimum balance of 100 should be maintained");
			}
			}
		else{
			System.out.println("Mobile number not found");
		}
	}

	@Override
	public double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		Customer custCheckBalance = custMap.get(mobileNo);
		double amount = custCheckBalance.getInitialBal();
		return amount;
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		String name, newMobileNo;
		float age;
		
		Customer custSender =  custMap.get(sender);
		Customer custReciever = custMap.get(reciever);
		
		double recieverAmount = custReciever.getInitialBal();
		double senderAmount = custSender.getInitialBal();
		if(senderAmount - amount > 500){
			recieverAmount += amount;
			senderAmount -= amount;
			name = custSender.getName();
			newMobileNo = custSender.getMobNo();
			age = custSender.getAge();
		
			
			custSender.setAge(age);
			custSender.setInitialBal(senderAmount);
			custSender.setMobNo(newMobileNo);
			custSender.setName(name);
			
			custMap.put(newMobileNo, custSender);
			
			name = custReciever.getName();
			newMobileNo = custReciever.getMobNo();
			age = custReciever.getAge();
			
			
			custReciever.setAge(age);
			custReciever.setInitialBal(recieverAmount);
			custReciever.setMobNo(newMobileNo);
			custReciever.setName(name);
			
			custMap.put(newMobileNo, custReciever);	
			System.out.println("Fund Transferred! new balance :"+senderAmount);
		}
		else{
			System.out.println("Cannot transfer! Minimum balance of 100 should be maintained in Sender's account");
		}
		
	}

	@Override
	public boolean validateAccount(String mobNo) throws BankException{
		Customer customer = custMap.get(mobNo);
		if(customer == null)
			return false;
		return true;
	}

}
